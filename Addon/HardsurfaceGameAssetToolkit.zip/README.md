在Addon目录下下载打包好的 .zip 文件
在Blender中安装插件
需要Blender 4.0以上版本
