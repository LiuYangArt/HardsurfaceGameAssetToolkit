在Addon目录下下载打包好的 .zip 文件
在Blender中安装插件
需要Blender 4.0以上版本

- 烘焙顶点色AO时blender crash可尝试修改注册表中的TDR值，直接导入Addon目录中附带的 TDRDelay.reg
  