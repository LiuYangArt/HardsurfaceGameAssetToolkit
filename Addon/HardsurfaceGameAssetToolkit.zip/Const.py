from bpy.utils import resource_path
from pathlib import Path

# bake groups
LOW_SUFFIX = "_low"
HIGH_SUFFIX = "_high"
LOW_COLOR = "COLOR_05"
HIGH_COLOR = "COLOR_06"
BAKECOLOR_ATTR = "BakeColor"

# hard surface props
UV_BASE = "UV0_Base"
UV_SWATCH = "UV1_Swatch"
WEARMASK_ATTR = "WearMask"
TRANSFER_COLLECTION = "_TransferNormal"
TRANSFER_MESH_PREFIX = "Raw_"
TRANSFER_PROXY_COLLECTION = "_TransferProxy"
TRANSFERPROXY_PREFIX = "TRNSP_"
COLLECTION_COLOR = "02"

MODIFIER_PREFIX = "HST"
BEVEL_MODIFIER = "HSTBevel"
NORMALTRANSFER_MODIFIER = MODIFIER_PREFIX + "NormalTransfer"
WEIGHTEDNORMAL_MODIFIER = MODIFIER_PREFIX + "WeightedNormal"
TRIANGULAR_MODIFIER = MODIFIER_PREFIX + "Triangulate"
COLOR_TRANSFER_MODIFIER = MODIFIER_PREFIX + "VertexColorTransfer"
COLOR_GEOMETRYNODE_MODIFIER = MODIFIER_PREFIX + "GNWearMask"

MATERIAL_PREFIX = "MI_"
SWATCH_MATERIAL = MATERIAL_PREFIX + "HSPropSwatch"

# import asset
ADDON_DIR = "HardsurfaceGameAssetToolkit"
ASSET_DIR = "PresetFiles"
USER = Path(resource_path("USER"))
ASSET_PATH = USER / "scripts/addons/" / ADDON_DIR / ASSET_DIR
NODE_FILE_PATH = ASSET_PATH / "GN_WearMaskVertexColor.blend"
PRESET_FILE_PATH = ASSET_PATH / "Presets.blend"

WEARMASK_NODE = "GN_HSTWearmaskVertColor"
LOOKDEV_HDR = "HDR_LookDev_Mid"

# socket
SOCKET_PREFIX = "SOCKET_"
SOCKET_SIZE = 0.3

# texel density
DEFAULT_TEX_DENSITY = 1024
DEFAULT_TEX_SIZE = 2048

# unreal axis visualizer
AXIS_COLLECTION = "_UE_AXIS_"
AXIS_OBJECT_PREFIX = "__HST_AXIS_"
AXIS_UP_ARROW = AXIS_OBJECT_PREFIX + "UpArrow"
AXIS_FRONT_ARROW = AXIS_OBJECT_PREFIX + "FrontArrow"
AXIS_ORIGIN = AXIS_OBJECT_PREFIX + "Origin"
AXIS_EMPTY = AXIS_OBJECT_PREFIX + "FrontDirection"
AXIS_ARROW = AXIS_OBJECT_PREFIX + "Arrows"
